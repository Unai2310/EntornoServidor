<?php
define('DB_SERVER','localhost');
define('DB_USER','unai');
define('DB_PASSWD','Un@isql23');
define('DATABASE','Usuarios');

